# high layer - synthetic layer

from typing import Union

from gsurface.imodel import SurfaceGuidedInteractedMassSystems
from gsurface.model import SurfaceGuidedMassSystem


def process(model: Union[SurfaceGuidedMassSystem, SurfaceGuidedInteractedMassSystems]):
    pass;
