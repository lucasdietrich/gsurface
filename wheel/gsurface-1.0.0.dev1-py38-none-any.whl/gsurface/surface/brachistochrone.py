from .surface import Surface, SJH


# https://en.wikipedia.org/wiki/Brachistochrone_curve
class Brachistochrone(Surface):
    pass